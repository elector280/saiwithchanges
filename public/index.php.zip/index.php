<?php
use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$parsedUrl  = parse_url($requestUri);

$path  = $parsedUrl['path'] ?? '';
$query = isset($parsedUrl['query']) ? '?' . $parsedUrl['query'] : '';

if ($path !== strtolower($path)) {
    $lowerUrl = strtolower($path) . $query;
    header('Location: ' . $lowerUrl, true, 301);
    exit;
}


// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../bootstrap/app.php';

$app->handleRequest(Request::capture());